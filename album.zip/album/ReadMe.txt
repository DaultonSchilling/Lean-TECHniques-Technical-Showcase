*How to Build

-Maven must be installed

In the folder called 'album' type cmd into the bar and hit enter. A command prompt should open.

  Enter these commands one at a time
  
  -mvn clean
  
  -mvn package
 
 Finally enter the following command-
  
  java -jar target/album-1.0-SNAPSHOT.jar
  
  
