package com.album;

/**
 *
 * @author Daulton Schilling
 */ 

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

public class ConsoleApp 
{

	private HttpURLConnection connection;
	private URL url;
	private BufferedReader reader;
	private StringBuffer responseContent;

	public ConsoleApp() 
        {
		responseContent = new StringBuffer();
	}
	public URLConnection getConnection() 
        {
		
		return connection;
	}

	public URL getUrl() 
        {
		return url;
	}

	public BufferedReader getReader() 
        {
		return reader;
	}

	
	public StringBuffer getResponseContent() 
        {
		
		return responseContent;
	}

	public void setUrl(int albumNum) 
        {

		try 
                {
			if (albumNum >= 1 && albumNum <= 100) 
                        {
				url = new URL("https://jsonplaceholder.typicode.com/photos?albumId=" + albumNum);

			} 
                        else 
                        {
				throw new OutOfBoundsException("Input Error. Please select a number between 1 and 100");
			}

		} 
                catch (MalformedURLException | OutOfBoundsException e) 
                {
		}

	}

	public void setConnection(HttpURLConnection connection) 
        {
		this.connection = connection;
	}

	public void setReader(BufferedReader reader) 
        {
		this.reader = reader;
	}

	
	public void setResponseContent(StringBuffer responseContent) 
        {
		this.responseContent = responseContent;
	}

	public void configConnection() throws ProtocolException 
        {
		connection.setRequestMethod("GET");
		connection.setConnectTimeout(5000);
		connection.setReadTimeout(5000);

	}


	public void createBuffer() 
        {

		String line;
		StringBuffer rc = new StringBuffer();
		try 
                {

			int status = connection.getResponseCode();
			if (status > 299) 
                        {
				setReader(new BufferedReader(new InputStreamReader(connection.getErrorStream())));

			} 
                        else
                        {
				setReader(new BufferedReader(new InputStreamReader(connection.getInputStream())));

			}
			while ((line = getReader().readLine()) != null) 
                        {

				rc.append(line);

			}
			reader.close();
		} 
                catch (ProtocolException e) 
                {
		} 
                catch (IOException e) 
                {
		}

		setResponseContent(rc);
	}

	
	public ArrayList<Album> createAlbumList() throws JsonParseException, IOException 
        {
		
		JsonFactory factory = new JsonFactory();
		JsonParser parser = factory.createParser(responseContent.toString());
		Album album = new Album();
		ArrayList<Album> list = new ArrayList();
		while (!parser.isClosed()) 
                {
			JsonToken jsonToken = parser.nextToken();

			if (JsonToken.FIELD_NAME.equals(jsonToken)) 
                        {
				String fieldName = parser.getCurrentName();

				parser.nextToken();
				if (null != fieldName) switch (fieldName) 
                                {
                                case "albumId":
                                    album.setAlbumId(parser.getValueAsInt());
                                    break;
                                case "id":
                                    album.setId(parser.getValueAsInt());
                                    break;
                                case "title":
                                    album.setTitle(parser.getValueAsString());
                                    break;
                                case "url":
                                    album.setUrl(parser.getValueAsString());
                                    break;
                                case "thumbnailUrl":
                                    album.setThumbnailUrl(parser.getValueAsString());
                                    list.add(album);
                                    album = new Album();
                                    break;
                                default:
                                    break;
                            }
			}
		}
		return list;

	}

	public void display(ArrayList<Album> list) 
        {
		System.out.println("> photo album number " + list.get(0).getAlbumId());
		System.out.println();
                list.stream().map(album -> 
                {
                    System.out.println("[" + album.getId() + "]" + album.getTitle());
                return album;
                }
                                  ).forEachOrdered(_item -> 
            {
                System.out.println();
            });

	}

}
