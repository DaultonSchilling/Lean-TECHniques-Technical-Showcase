package com.album;

/**
 *
 * @author Daulton Schilling
 */

public class OutOfBoundsException extends RuntimeException 
{

	

	public OutOfBoundsException(String message)
        {
		super(message);
		
	}

}
