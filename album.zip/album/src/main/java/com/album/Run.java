package com.album;

/**
 *
 * @author Daulton Schilling
 */

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.util.Scanner;

public class Run {

	public static void main(String[] args) 
        {
            
		ConsoleApp app = new ConsoleApp();
		
		try 
                {
                    
			System.out.println("Please select an album to display between 1 and 100");
                        
                        int albumNum;
                        
                    try (Scanner sc = new Scanner(System.in)) 
                    {
                        albumNum = sc.nextInt();
                    }
			
			app.setUrl(albumNum);
			app.setConnection((HttpURLConnection) app.getUrl().openConnection());
			app.configConnection();
			
			app.createBuffer();
			app.display(app.createAlbumList());

		} 
                catch (MalformedURLException e) 
                {
		} 
                catch (IOException e) 
                {
			System.out.println("Input Error. Please select a number between 1 and 100");
		} 
                catch (IndexOutOfBoundsException e) 
                {
			System.out.println("Incorrect ID number, please try again");
		}

	}

}
