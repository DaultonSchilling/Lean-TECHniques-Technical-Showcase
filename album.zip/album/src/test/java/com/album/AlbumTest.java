package com.album;

/**
 *
 * @author Daulton Schilling
 */

import static org.junit.Assert.*;

import org.junit.Test;

public class AlbumTest 
{

	Album a = new Album(1,2,null,null,null);
	
	
	@Test
        
	public void TestGetAlbumId() 
        {
		assertEquals(1, a.getAlbumId());
	}

	
	@Test
        
	public void TestSetAlbumId() 
        {
		a.setAlbumId(20);
		assertNotEquals(2, a.getAlbumId());
		assertEquals(20, a.getAlbumId());
	}

	
	@Test
        
	public void TestGetId() 
        {
		assertEquals(2, a.getId());
		
	}

	
	@Test
        
	public void TestSetId() 
        {
		a.setId(4);
		assertNotEquals(2,a.getId());
		assertEquals(4, a.getId());
	}

	
	@Test
        
	public void TestGetTitle() 
        {
		assertEquals(null, a.getTitle());
	}

	
	@Test
        
	public void TestSetTitle() 
        {
		a.setTitle("testing the title");
		assertNotEquals(null,a.getTitle());
		assertEquals("testing the title", a.getTitle());
	}

	
	@Test
        
	public void TestGetUrl() 
        {
		assertEquals(null, a.getUrl());
	}

	
	@Test
        
	public void TestSetUrl() 
        {
		a.setUrl("testing the url");
		assertNotEquals(null, a.getUrl());
		assertEquals("testing the url", a.getUrl());
	}

	
	@Test
        
	public void TestGetThumbnailUrl() 
        {
		assertEquals(null, a.getThumbnailUrl());
	}

	
	@Test
        
	public void TestSetThumbnailUrl() 
        {
		a.setThumbnailUrl("testing the thumbnail");
		assertNotEquals(null, a.getThumbnailUrl());
		assertEquals("testing the thumbnail", a.getThumbnailUrl());
	}

}
