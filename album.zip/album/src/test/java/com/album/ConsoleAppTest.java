package com.album;

/**
 *
 * @author Daulton Schilling
 */

import static org.junit.Assert.*;

import java.io.IOException;
import java.net.HttpURLConnection;

import org.junit.Test;

public class ConsoleAppTest 
{
	
	ConsoleApp app = new ConsoleApp();

	@Test
        
	public void TestConfigConnection() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		app.configConnection();
		assertEquals(5000, app.getConnection().getConnectTimeout());
		assertEquals(5000, app.getConnection().getReadTimeout());
		
	}
	
	@Test
        
	public void TestCreateBuffer() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		app.configConnection();
		app.createBuffer();
		
		assertNotNull(app.getResponseContent());
		
	}
	
	@Test
        
	public void TestCreateAlbumList() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		app.configConnection();
		app.createBuffer();
		
		assertNotNull(app.createAlbumList());
		
	}
	
	@Test
        
	public void TestCreateAlbumListSize() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		app.configConnection();
		app.createBuffer();
		
		assertEquals(50, app.createAlbumList().size());
		
	}
	
	@Test
        
	public void TestCreateAlbumListIde() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		app.configConnection();
		app.createBuffer();
		
		assertEquals(1, app.createAlbumList().get(0).getAlbumId());
		
	}

}
