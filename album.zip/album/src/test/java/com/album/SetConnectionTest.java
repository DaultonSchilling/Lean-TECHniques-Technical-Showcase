package com.album;

/**
 *
 * @author Daulton Schilling
 */

import static org.junit.Assert.*;

import java.io.IOException;
import java.net.HttpURLConnection;

import org.junit.Test;

public class SetConnectionTest 
{
	
	ConsoleApp app = new ConsoleApp();
	
	@Test
        
	public void checkNullConnectionTest() throws IOException
        {
		assertNull(app.getConnection());
	}

	@Test
        
	public void TestSetConnection1() throws IOException 
        {
		app.setUrl(1);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection2() throws IOException 
        {
		app.setUrl(2);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection3() throws IOException 
        {
		app.setUrl(3);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection4() throws IOException 
        {
		app.setUrl(4);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection5() throws IOException {
		app.setUrl(5);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection6() throws IOException 
        {
		app.setUrl(6);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection7() throws IOException 
        {
		app.setUrl(7);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection8() throws IOException 
        {
		app.setUrl(8);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection9() throws IOException 
        {
		app.setUrl(9);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}
	
	@Test
        
	public void TestSetConnection10() throws IOException 
        {
		app.setUrl(10);
		app.setConnection((HttpURLConnection) app.getUrl().openConnection());
		assertNotNull(app.getConnection());
	}

}
