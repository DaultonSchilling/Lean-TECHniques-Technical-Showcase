package com.album;

/**
 *
 * @author Daulton Schilling
 */

import static org.junit.Assert.assertEquals;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import org.junit.Test;

public class SetUrlTest 
{

	ConsoleApp app = new ConsoleApp();
	HttpURLConnection conn;

	@Test
        
	public void TestSetUrl1() throws MalformedURLException
        {
		app.setUrl(1);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 1, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl2() throws MalformedURLException 
        {
		app.setUrl(2);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 2, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl3() throws MalformedURLException 
        {
		app.setUrl(3);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 3, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl4() throws MalformedURLException 
        {
		app.setUrl(4);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 4, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl5() throws MalformedURLException 
        {
		app.setUrl(5);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 5, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl6() throws MalformedURLException 
        {
		app.setUrl(6);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 6, app.getUrl().toString());

	}
	
	@Test
	public void TestSetUrl7() throws MalformedURLException 
        {
		app.setUrl(7);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 7, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl8() throws MalformedURLException 
        {
		app.setUrl(8);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 8, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl9() throws MalformedURLException 
        {
		app.setUrl(9);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 9, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrl10() throws MalformedURLException 
        {
		app.setUrl(10);
		assertEquals("https://jsonplaceholder.typicode.com/photos?albumId=" + 10, app.getUrl().toString());

	}
	
	@Test
        
	public void TestSetUrlBad() throws MalformedURLException 
        {
		app.setUrl(11);
		
	}

	

}
